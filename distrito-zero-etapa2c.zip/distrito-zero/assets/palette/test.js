// Paleta de TESTE da Etapa 1 (só prova o carregador). A paleta mestre sai das imagens de referência na Etapa 2.
export const palette = {
  'grama.1': [31, 58, 42], 'grama.2': [43, 77, 52], 'grama.3': [58, 100, 64],
  'pedra.1': [42, 47, 61], 'pedra.2': [58, 65, 82], 'pedra.3': [77, 86, 107],
  'muro.1': [20, 24, 42], 'muro.2': [34, 40, 66],
  'sonda.1': [122, 74, 18], 'sonda.2': [232, 163, 61], 'sonda.3': [246, 210, 122],
};
